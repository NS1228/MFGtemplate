# NavMesh in Unity
Project files for my tutorial on pathfinding using Unity's NavMesh Tools.

Check out my [YouTube Channel](http://youtube.com/brackeys) for more tutorials.

Everything is free to use, also commercially (public domain).